#5번 C235379 정유진

def main():
    a = Shape()
    b = Shape("red")
    cpoint = CPoint(4,7)
    c = Shape("black", False, cpoint)
    print(a)
    print(b)
    print(c)
    a.move(2,3)
    print(a)
    print(b.move(4,5))
    d = Circle("blue", False, 10).move(3,4)
    print(d)
    e = Rectangle("blue", False, 10, 20)
    print(e.move(7,8))


class CPoint:
    def __init__(self, x=0, y=0):
        self.x = x
        self.y = y
        
    def move(self, a, b):
        self.x = self.x + a
        self.y = self.y + b
        return self
    
    def __str__(self):
        return f'pos({self.x}, {self.y})'
    
    
class Shape:
    def __init__(self, color='yellow', filled=True, cpoint=None):
        self.color = color
        self.filled = filled
        if cpoint == None:
            cpoint = CPoint()
            self.cpoint = (cpoint.x, cpoint.y)
        else:
            self.cpoint = (cpoint.x, cpoint.y)
    
    def move(self, a, b):
        self.cpoint = (self.cpoint[0]+a, self.cpoint[1]+b)
        return self
        
    def __str__(self):
        return f'pos({self.cpoint[0]}, {self.cpoint[1]})({self.color}, {self.filled})'
    
        
class Circle(Shape):
    def __init__(self, color, filled, radius):
        super().__init__(color, filled)
        self.radius = radius
        
    def area(self):
        return self.radius*self.radius*3.14
    
    def __str__(self):
        return f'{super().__str__()}(radius = {self.radius})'
    
    
class Rectangle(Shape):
    def __init__(self, color, filled, width, height):
        super().__init__(color, filled)
        self.width = width
        self.height = height
        
    def area(self):
        return self.width*self.height
    
    def __str__(self):
        return f'{super().__str__()}({self.width}, {self.height})'
        
    
main()