#6. C235375 정예원
class Parent1:
    def __init__(self,a):
        super().__init__()
        self.p1=a
    def show(self):
        print("Inside Parent1",self.p1)
    def display(self):
        print("Inside Parent1",self.p1)
        
class Parent2:
    def __init__(self,a,b):
        super().__init__(a)
        self.p2=b
    def display(self):
        print("Inside Parent2",self.p2)

class Child(Parent2, Parent1):
    def __init__(self, a, b, c):
        super().__init__(a,b)
        self.c=c
    def show(self):
        print("Inside Child",self.c)

obj=Child(1,2,3)

obj.show()
obj.display()