#2 c235367 정성현
class Shape:
    def __init__(self, color="yellow", filled=True):
        self.color=color
        self.filled=filled
    def __str__(self):
        return f'({self.color},{self.filled})'
class Rectangle(Shape):
    def __init__(self, color, filled, w, h):
        super().__init__(color,filled)
        self.w=w
        self.h=h
    def __str__(self):
        return f'({self.color},{self.filled})({self.w},{self.h})'
    def area(self):
        return self.w*self.h
def main() :
 c = Rectangle("blue",False,10,20)
 print(c)
 print(c.area())
main()