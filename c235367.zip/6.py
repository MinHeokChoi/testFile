#6 c235367 정성현
class Parent1 : 
 def __init__(self,b) :
  super().__init__()
  self.p2 = b
 def show(self): 
  print("Inside Parent1",self.p1)
 def display(self) :
  print("Inside Parent1",self.p1)
class Parent2 : 
 def __init__(self,a,b) :
  super().__init__(b)
  self.p1 = a
 def display(self): 
  print("Inside Parent2",self.p2)
class Child(Parent2, Parent1): 
 def __init__(self,a,b,c) :
  super().__init__(a,b)
  self.c = c
 def show(self): 
  print("Inside Child",self.c)

obj = Child(1,2,3) 
obj.show() 
obj.display() 