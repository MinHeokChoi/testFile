#4 c235367 정성현
class CPoint:
    def __init__(self,x=0,y=0):
        self.x=x
        self.y=y
    def move(self,m,n):
        self.m=m
        self.n=n
        self.x+=m
        self.y+=n
        return self
    def __str__(self):
        return f'pos({self.x},{self.y})'
class Shape(CPoint):
    k=0
    def __init__(self, color="yellow", filled=True, x=0, y=0,m=0,n=0):
        super().__init__(x,y)
        self.color=color
        self.filled=filled
    def move(self,m,n):
        self.m=m
        self.n=n
        self.x+=m
        self.y+=n
        self.k=Shape.k
        print(f'pos({self.x},{self.y})',end='')
        self.k+=1
        return self
    def __str__(self):
        if self.k==0:
            return f'pos({self.x},{self.y})({self.color},{self.filled})'
        else :
            return f'({self.color},{self.filled})'
class Rectangle(Shape):
    def __init__(self, color, filled, w, h):
        super().__init__(color,filled)
        self.w=w
        self.h=h
    def __str__(self):
        return f'({self.color},{self.filled})({self.w},{self.h})'
    def area(self):
        return self.w*self.h
class Circle(Shape):
    def __init__(self, color, filled, r):
        super().__init__(color,filled)
        self.r=r
    def __str__(self):
        return f'({self.color},{self.filled})(radius={self.r})'
    def area(self):
        return (self.r**2)*3.14
def main() :
 a = Shape()
 b = Shape("red")
 c = Shape("black",False,1,2)
 print(a)
 print(b)
 print(c)
 a.move(2,3)
 print(a)
 print(b.move(4,5))
 d = Circle("blue",False,10).move(3,4)
 print(d)
 e = Rectangle("blue",False,10,20)
 print(e.move(7,8))
main()