#1 c235367 정성현
class Shape:
    def __init__(self, color="yellow", filled=True):
        self.color=color
        self.filled=filled
    def printf(self):
        print(f'({self.color},{self.filled})')
    def __str__(self):
        return f'({self.color},{self.filled})'
class Circle(Shape):
    def __init__(self, color, filled, r):
        super().__init__(color,filled)
        self.r=r
    def __str__(self):
        return f'({self.color},{self.filled})(radius={self.r})'
    def area(self):
        return (self.r**2)*3.14
def main() :
 a = Shape()
 b = Shape("red")
 print(a,b)
 c = Circle("blue",False,10)
 print(c)
 print(c.area())
main()